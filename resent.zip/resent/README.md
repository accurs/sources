Made by me (divinity(x32u))

Earlier version of Evict's leaked code.